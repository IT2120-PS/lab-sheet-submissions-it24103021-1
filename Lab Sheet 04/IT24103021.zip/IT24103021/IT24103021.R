# Exercise 
setwd("C:/Users/it24103021/Desktop/IT24103021")

# 01 - Import dataset
branch_data <- read.csv("Exercise.txt", header=TRUE)
fix(branch_data)
attach(branch_data)

# 02 - Variable types and scale of measurement
str(branch_data)

# 03 - Boxplot for sales
boxplot(branch_data$Sales_X1, main="Boxplot of Sales",outline=TRUE, outpch=8, horizontal=TRUE)

# 04 - Five number summary and IQR for advertising
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# 05 - Outlier function (same as above, applied to Years_X3)
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  IQR <- q3 - q1
  
  ub <- q3 + 1.5*IQR
  lb <- q1 - 1.5*IQR
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse=", ")))
}
# Check for outliers in Years variable
get.outliers(branch_data$Years_X3)
